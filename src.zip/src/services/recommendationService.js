import { db } from "../lib/firebase"
import { collection, getDocs } from "firebase/firestore"

export async function getPopularGames() {

  const snapshot = await getDocs(collection(db, "games"))

  const games = snapshot.docs.map(doc => doc.data())

  return games.slice(0,3)
}