import { db } from "../lib/firebase"
import { collection, query, where, getDocs } from "firebase/firestore"

export async function getMachines(zoneId, gameType) {

  const q = query(
    collection(db, "machines"),
    where("zoneId", "==", zoneId),
    where("gameType", "==", gameType)
  )

  const snapshot = await getDocs(q)

  return snapshot.docs.map(doc => ({
    id: doc.id,
    ...doc.data()
  }))
}