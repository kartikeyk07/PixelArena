import { db } from "../lib/firebase"
import { collection, getDocs } from "firebase/firestore"

export async function getStats() {

  const usersSnapshot = await getDocs(collection(db, "users"))
  const zonesSnapshot = await getDocs(collection(db, "zones"))
  const bookingsSnapshot = await getDocs(collection(db, "bookings"))

  return {
    totalUsers: usersSnapshot.size,
    totalZones: zonesSnapshot.size,
    totalBookings: bookingsSnapshot.size
  }
}