"use client"

import { useEffect, useState } from "react"
import { db } from "@/lib/firebase"
import {
  collection,
  getDocs
} from "firebase/firestore"
import AdminSidebar from "@/components/AdminSidebar"
import { FaMapMarkerAlt, FaGamepad, FaUtensils, FaUsers, FaChartBar } from "react-icons/fa"

export default function AdminDashboard() {
  const [stats, setStats] = useState({
    zones: 0,
    games: 0,
    menuItems: 0
  })

  async function loadStats() {
    const [zonesSnap, gamesSnap, menuSnap] = await Promise.all([
      getDocs(collection(db, "zones")),
      getDocs(collection(db, "games")),
      getDocs(collection(db, "menu"))
    ])

    setStats({
      zones: zonesSnap.size,
      games: gamesSnap.size,
      menuItems: menuSnap.size
    })
  }

  useEffect(() => {
    loadStats()
  }, [])

  const statCards = [
    {
      title: "Total Zones",
      value: stats.zones,
      icon: FaMapMarkerAlt,
      color: "bg-purple-600",
      href: "/admin/zones"
    },
    {
      title: "Total Games",
      value: stats.games,
      icon: FaGamepad,
      color: "bg-blue-600",
      href: "/admin/games"
    },
    {
      title: "Menu Items",
      value: stats.menuItems,
      icon: FaUtensils,
      color: "bg-green-600",
      href: "/admin/menu"
    }
  ]

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex">
      <AdminSidebar />

      {/* Main Content */}
      <div className="flex-1 p-8">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-3xl font-bold text-slate-100 mb-8">
            Admin Dashboard
          </h1>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            {statCards.map((card, index) => {
              const Icon = card.icon
              return (
                <a
                  key={index}
                  href={card.href}
                  className="bg-slate-800 p-6 rounded-lg border border-slate-700 hover:bg-slate-750 transition-colors duration-200 block group"
                >
                  <div className="flex items-center">
                    <div className={`p-3 ${card.color} rounded-lg group-hover:scale-110 transition-transform duration-200`}>
                      <Icon className="text-white text-xl" />
                    </div>
                    <div className="ml-4">
                      <p className="text-slate-400 text-sm">{card.title}</p>
                      <p className="text-2xl font-bold text-slate-100">{card.value}</p>
                    </div>
                  </div>
                </a>
              )
            })}
          </div>

          {/* Quick Actions */}
          <div className="bg-slate-800 p-6 rounded-lg border border-slate-700">
            <h2 className="text-xl font-semibold text-slate-100 mb-6">Quick Actions</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <a
                href="/admin/zones"
                className="bg-purple-600 hover:bg-purple-700 text-white p-4 rounded-lg font-medium transition-all duration-200 flex items-center justify-center gap-2 hover:scale-105"
              >
                <FaMapMarkerAlt />
                Manage Zones
              </a>
              <a
                href="/admin/games"
                className="bg-blue-600 hover:bg-blue-700 text-white p-4 rounded-lg font-medium transition-all duration-200 flex items-center justify-center gap-2 hover:scale-105"
              >
                <FaGamepad />
                Add Games
              </a>
              <a
                href="/admin/menu"
                className="bg-green-600 hover:bg-green-700 text-white p-4 rounded-lg font-medium transition-all duration-200 flex items-center justify-center gap-2 hover:scale-105"
              >
                <FaUtensils />
                Manage Menu
              </a>
            </div>
          </div>

          {/* Recent Activity Placeholder */}
          <div className="bg-slate-800 p-6 rounded-lg border border-slate-700 mt-8">
            <h2 className="text-xl font-semibold text-slate-100 mb-6">Recent Activity</h2>
            <div className="text-slate-400 text-center py-8">
              Activity feed will be implemented with real-time updates
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}