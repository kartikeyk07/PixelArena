"use client"

import { motion } from "framer-motion"
import Link from "next/link"

export default function Home() {

  return (
    <div className="min-h-screen bg-black text-white flex flex-col items-center justify-center">

      <motion.h1
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="text-6xl font-bold"
      >
        Zone Gaming
      </motion.h1>

      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.4 }}
        className="text-gray-400 mt-4 text-lg"
      >
        Book your gaming experience
      </motion.p>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.8 }}
        className="flex gap-6 mt-10"
      >

        <Link href="/zones">
          <button className="bg-purple-600 px-6 py-3 rounded-lg hover:bg-purple-700 transition">
            Explore Zones
          </button>
        </Link>

        <Link href="/login">
          <button className="border border-purple-500 px-6 py-3 rounded-lg hover:bg-purple-500 hover:text-black transition">
            Login
          </button>
        </Link>

        <Link href="/register">
          <button className="border border-purple-500 px-6 py-3 rounded-lg hover:bg-purple-500 hover:text-black transition">
            Register
          </button>
        </Link>

      </motion.div>

    </div>
  )
}