"use client"

import { useEffect, useState } from "react"
import { getUserBookings } from "@/services/bookingService"
import { useAuth } from "@/context/AuthContext"
import UserSidebar from "@/components/UserSidebar"
import { FaGamepad, FaCalendarAlt, FaClock, FaCreditCard } from "react-icons/fa"

export default function BookingHistory() {
  const { user } = useAuth()
  const [bookings, setBookings] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function loadBookings() {
      if (!user) return

      try {
        const data = await getUserBookings(user.uid)
        setBookings(data)
      } catch (error) {
        console.error("Error loading bookings:", error)
      } finally {
        setLoading(false)
      }
    }

    loadBookings()
  }, [user])

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-900 text-slate-100 flex items-center justify-center">
        <div className="text-slate-400">Loading bookings...</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex">
      <UserSidebar />
      <div className="flex-1">
        <div className="max-w-7xl mx-auto p-8">
          <h1 className="text-3xl font-bold text-slate-100 mb-8">
            My Bookings
          </h1>

        {bookings.length > 0 ? (
          <div className="space-y-6">
            {bookings.map((booking) => (
              <div
                key={booking.id}
                className="bg-slate-800 p-6 rounded-lg border border-slate-700 hover:bg-slate-750 transition-colors duration-200"
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-4">
                    <div className="p-3 bg-blue-600 rounded-lg">
                      <FaGamepad className="text-white text-xl" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-semibold text-slate-100 mb-2">
                        {booking.gameName || 'Unknown Game'}
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
                        <div className="flex items-center text-slate-300">
                          <FaCalendarAlt className="mr-2 text-purple-400" />
                          <span>Slot: {booking.slot || 'N/A'}</span>
                        </div>
                        <div className="flex items-center text-slate-300">
                          <FaClock className="mr-2 text-green-400" />
                          <span>Duration: {booking.duration || 0} hours</span>
                        </div>
                        <div className="flex items-center text-slate-300">
                          <FaCreditCard className="mr-2 text-orange-400" />
                          <span>Payment: {booking.paymentMethod || 'N/A'}</span>
                        </div>
                        <div className="flex items-center text-slate-300">
                          <span className="text-slate-400">Status:</span>
                          <span className="ml-2 px-2 py-1 bg-green-600/20 text-green-400 rounded text-xs">
                            Confirmed
                          </span>
                        </div>
                      </div>
                      {booking.createdAt && (
                        <p className="text-slate-400 text-sm mt-2">
                          Booked on: {booking.createdAt?.toDate?.()?.toLocaleDateString() || 'Unknown Date'}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="bg-slate-800 p-12 rounded-lg border border-slate-700 text-center">
            <FaGamepad className="text-slate-400 text-6xl mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-slate-100 mb-2">No bookings yet</h3>
            <p className="text-slate-400 mb-6">
              You haven't made any bookings yet. Start exploring our gaming zones!
            </p>
            <a
              href="/zones"
              className="inline-block bg-purple-600 hover:bg-purple-700 text-white px-6 py-3 rounded-lg font-medium transition-colors duration-200"
            >
              Browse Gaming Zones
            </a>
          </div>
        )}
        </div>
      </div>
    </div>
  )
}